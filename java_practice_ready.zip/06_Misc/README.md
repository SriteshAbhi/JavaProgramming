# 06_Misc

This folder contains Java programs classified under **06_Misc**.

## Files
- (no files)

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
