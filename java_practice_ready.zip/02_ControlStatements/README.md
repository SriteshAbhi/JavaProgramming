# 02_ControlStatements

This folder contains Java programs classified under **02_ControlStatements**.

## Files
- `Code.java`
- `Enum.java`
- `Enum2.java`
- `ExceptionMethod.java`
- `InsertionSort.java`
- `Man.java`
- `MyExceotion.java`
- `MyException1.java`
- `SelectionSort.java`
- `Test.java`
- `Threads.java`
- `Work.java`
- `enhancefor.java`
- `fan.java`
- `sai.java`
- `student.java`

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
