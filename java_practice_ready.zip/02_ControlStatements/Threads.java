class Home
{
    int count;
    public synchronized void incre()
    {
        count=count+1;
    }
}
public class Threads {
    public static void main(String[] args) throws InterruptedException {
        Home h1=new Home();
        Runnable r1=()->{
            for(int i=1;i<=1000;i++){
                   h1.incre();
            }
                          
        };
        Runnable r2=()->{
            for(int i=1;i<=1000;i++){
                   h1.incre();
            }
                          
        };
        Thread t1=new Thread(r1);
        Thread t2=new Thread(r2);
        t1.start();
        t2.start();
        t1.join();
        t2.join();
        
        System.out.println(h1.count);


    }


    
}