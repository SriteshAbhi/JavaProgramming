// Custom exception
class MyException extends RuntimeException {
    public MyException(String message) {
        super(message);  // Pass the message to the parent class constructor
    }
}




// Class A with a method that can throw ClassNotFoundException
class A {
    public void hello() throws ClassNotFoundException {
        // Attempting to load a class "Demoko"
        Class.forName("Demoko");  // Demoko class doesn't exist, so this will throw ClassNotFoundException
    }
}

// Class Demo with a method that throws MyException
class Demo {
    public void good() {
        int i = 9;
        if (i == 9) {
            // Throwing the custom MyException
            throw new MyException("my problem");
        }
    }
}

public class ExceptionMethod {
    public static void main(String[] args) {
        A a1 = new A();  // Instance of class A
        Demo d1 = new Demo();  // Instance of class Demo
        
        try {
            // Try to call hello() from class A (may throw ClassNotFoundException)
            a1.hello();
            // Try to call good() from class Demo (may throw MyException)
            d1.good();
            
        }   catch (MyException g) {
            // Handle MyException
            System.out.println("Caught MyException: " + g.getMessage());
        }
        catch (ClassNotFoundException e) {
            // Handle ClassNotFoundException
            System.out.println("Caught ClassNotFoundException: " + e.getMessage());
        }
    }
}
