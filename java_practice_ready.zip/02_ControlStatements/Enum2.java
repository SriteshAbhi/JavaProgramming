enum SmartPhone
{
    mi(10000),realme(15000),iphone(100000),moto(10500),samsung(20000),vivo(18000);
    int price;
SmartPhone (int price)
   {
    this.price=price;
   }
public int getPrice() {
    return price;
}
public void setPrice(int price) {
    this.price = price;
}


}
public class Enum2 {
    public static void main(String[] args) {
        SmartPhone s=SmartPhone.iphone;
        for(SmartPhone sop:SmartPhone.values())
        {
            System.out.println(sop+" : "+sop.getPrice());
        }
         
        
    }
    
}
