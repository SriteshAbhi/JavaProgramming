class num
{
    int rollno;
    String name;
    int marks;


}

public class student {
    /**
     * @param args
     */
    public static void main(String[] args) {

        num n1=new num();
        n1.rollno=1;
        n1.name="rajesh";
        n1.marks=202;
       
        num n2=new num();
        n2.rollno=2;
        n2.name="rash";
        n2.marks=20;

        num n3=new num();
        n3.rollno=3;
        n3.name="rajsh";
        n3.marks=203;

        num   n[] = new  num[3];
        n[0]=n1;
        n[1]=n2;
        n[2]=n3;

         for(num sl:n)
         {
            System.out.println(sl.name);

         }


    }
    
}
