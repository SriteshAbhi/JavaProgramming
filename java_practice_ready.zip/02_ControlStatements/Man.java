import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
class Vechile implements comparable<Vechile>

{
    int price;
    String name;
    public Vechile(int price, String name) {
        this.price = price;
        this.name = name;
    }
    @Override
    public String toString() {
        return "Vechile [price=" + price + ", name=" + name + "]";
    }
    public int compareTo(Vechile that)
    {
            if(this.price>that.price)
            {
                 return 1;
            }
            else{
                return-1;
        }
        
    }

}

public class Man {
    public static void main(String[] args) {

        Comparator<Vechile> com=new Comparator<Vechile>()
        {
            public int compare(Vechile i,Vechile j)
            {
                if(i.price> j.price)
                {
                    return 1;
                }
                else{
                    return -1;
                }
            }
        };
     List<Vechile>  vechiles=new ArrayList<>(); 
      vechiles.add(new Vechile(10000, "ford"));
     
      vechiles.add(new Vechile(3000, "suzuki"));
      vechiles.add(new Vechile(700000,"scorpio"));
      vechiles.add(new Vechile(5000, "thar"));
    // System.out.println(list);
Collections.sort(vechiles); 
for(Vechile n:vechiles)
{
    System.out.println(n);
}
    }
}
