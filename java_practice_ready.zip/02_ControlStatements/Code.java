import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;

public class Code {

    public static void main(String[] args) {
        Map<String,Integer> stud=new Hashtable ();
        stud.put("sritesh", 67);
        stud.put("bablu", 89);
        stud.put("bubby", 90);
        stud.put("vishnutha", 347);
        stud.put("bava", 77);
        for(String key:stud.keySet())
        {
            System.out.println(key+":"+stud.get(key));
        }
        
    }
}