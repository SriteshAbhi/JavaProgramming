public class enhancefor {
    public static void main(String[] args) {
        int arr[]=new int[3];
        for(int n:arr)
        {
            n=(int)(Math.random()*10);
        }
        for(int m:arr){
            System.out.println(m);
        }

    }
    
}
