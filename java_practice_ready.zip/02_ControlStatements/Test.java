 class BankApp
 {
    int balance=0;
    public void depositMoney(int amount)
    {
        System.out.println("you deposited amount"+balance);
        this.balance+=amount;
        System.out.println("current balace:"+this.balance);
        
    }
    public void withdrawMoney(int amount)
    
    {
        if(balance>=amount)
        {
        System.out.println("take your cash"+amount);
        this.balance-=amount;
        System.out.println("Balance:"+balance);
        }
        else
        {
            System.out.println("insufficient bank baance");
        }
    }
    public void cashBalance()
    {
        System.out.println("Bank Balance:"+balance);
    }
 }
 public class Test extends BankApp
 {
     
 
    public static void main(String[] args) {
        BankApp t1=new Test();
        t1.cashBalance();
        
    }
 }