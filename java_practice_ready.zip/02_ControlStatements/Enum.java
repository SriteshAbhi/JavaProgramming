enum Status
{
    running,over,succes,pending,failed
}
public class Enum {
    public static void main(String[] args) {
        Status[] s=Status.values();
        int x=s.length;
        for(int i=0;i<x;i++)
        {
           System.out.println(s[i]+" : "+s[i].ordinal());
        }
        System.out.println("----------------------");
        for(Status n: s)
        {
            System.out.println(n+" : "+n.ordinal());
        }
        
    }
}
    

