 // Custom exception
class MyException extends RuntimeException {
    public MyException(String message) {
        super(message);
    }
}

// Class A
class A {
    public void hello() throws ClassNotFoundException {
        Class.forName("Demoj");  // This tries to load the Demo class
    }
}

// Class Demo
class Demo {
    public void good() {
        int i = 9;
        if (i == 9)
            throw new MyException("my problem");  // Throwing a custom exception
    }
}

class MyException1{
    public static void main(String[] args) {
        // Creating an object of A and calling hello
        A a1 = new A();
        try {
            a1.hello();  // Tries to load the Demo class
        } catch (ClassNotFoundException e) {
            System.out.println("problem " + e.getMessage());  // Handle ClassNotFoundException
        }

        // Creating an object of Demo and calling good
        Demo d1 = new Demo();
        try {
            d1.good();  // This will throw MyException
        } catch (MyException e) {
            System.out.println("Caught MyException: " + e.getMessage());  // Handle MyException
        }
    }
}
