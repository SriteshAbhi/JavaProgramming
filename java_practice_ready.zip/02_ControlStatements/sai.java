 public class sai {
    public static int  main(String[] args) {
         
    
 
    
        int a=10,b=20;
    d.swapNumbers(a,b);
    String result= check(a,b);
    System.out.println(result);
 int  m=(int) d.area(a);
 return m;
    
 
    
}
    
    public static  int add(int x,int y)
    {
        int res=x+y;
        return res;
    }
    public  static String check(int a,int b)
    {
    if(add(a,b)==a+b)
    {
        return "True";
        
    }
    else{
        return "False";
    }
}
}
class d{

 
public static  void swapNumbers(int c,int d)
{
    System.out.println("before swappin a=:"+c+"  b="+d);
    int m=c;
    c=d;
    d=m;
    System.out.println("after swapping a="+c+"  b="+d);
   

}
public static float  area(int h)
{
    System.out.println("the area for cricle with radius "+h+"is :");
    float area= (float)(3.14159265358979)*(h*h);
    return area;
} 
 }