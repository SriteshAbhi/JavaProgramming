class MyException extends RuntimeException
{
    
    
        public  MyException(String g)
        {
                super(g);
        }
} 
    
    public class MyExceotion {
        
        
            public static void main(String[] args) {
                int i=0;
                try{
                 i=3/1;;
                 if(i==3)
                 {
                    throw new  MyException("hello");
         }

        }
        catch(MyException sri)
        {
            System.out.println(sri.getMessage());
        }
        System.out.println("i value:"+i);
    }
    
}
