import java.util.Arrays;

public class SelectionSort {
  public static void printArray(int[] crr)
  {
    System.out.println(Arrays.toString(crr));
  }

  public static void main(String[] args) {
    int[] arr={2,6,7,3,1};
    for(int i=0;i<arr.length-1;i++)
    {
        int smaller=i;
      for(int j=i+1;j<arr.length;j++)
      {
        if(arr[smaller]>arr[j])
        {
           smaller=j;
        }
      }
      int temp=arr[i];
          arr[i]=arr[smaller];
          arr[smaller]=temp;
    }
    printArray(arr);
    
  }
}