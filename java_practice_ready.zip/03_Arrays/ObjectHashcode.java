class D
{
   String day;
   String date;
   public String toString()
   {
    return day +":"+"hello";
   }
    
}
public class ObjectHashcode {
    public static void main(String[] args) {
        D d1=new D();
        d1.day="monday";
        d1.date="hello";

        D d2=new D();
        d2.day="monday";
        d2.date="hello1";
        boolean h=(d1.day==d2.day) && (d1.date==d2.date);
        System.out.println(h);

       // System.out.println(d1);//class +hashcode(hexa)
    }
}
