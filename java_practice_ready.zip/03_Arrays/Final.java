  final class A
{
   public  final int x=10;
    
    final public void show()
    {
        x=6;//NO CHANGES CAN BE MADE TO THE FINAL VARIABLE
        System.out.println("in a"+x);
    }
}
class b extends A  // the final class can't be inherited
{
    public void show()  //the final method can't be overriding 
    {
        System.out.println("in b");
    }
}
    

public class Final {
    public static void main(String[] args) {
        A a1=new A();
        a1.show();
    }

    
}
