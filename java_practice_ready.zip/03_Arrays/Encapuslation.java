import sritesh.CodeStatic;
class Human
{
    private int  pin;
   private String name="sritesh";

   public int accPin(int y)
   {
     pin=y;
     return y;
    
   }

  public int getPin() {
    return pin;
  }

  public void setPin(int pin) {
    this.pin = pin;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }
   
}
//PRIVATE VARIABLES ARE ACCESSED BY ONLY WITHIN THE SAME CLASS ONLY
//THEY CAN BE ACCESSED BY CREATE A METHOD THAT RETURNS THE AGE


public class Encapuslation {
    public static void main(String[] args) {
        Human h1= new Human();
        Kurkure h=new Kurkure();
        h.brand="jdjdk";
        System.out.println(h.brand);
        h1.setPin(234);
         System.out.println((h1.accPin(8919)));
       
    
   // h1.setPin(234);

    
}
}
