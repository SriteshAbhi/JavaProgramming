import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.TreeSet;
import java.util.Map;

public class Practice {
    public static void main(String[] args) {
        Map<String,Integer> m1=new HashMap<>();
         m1.put("sritesh",1);
         m1.put("saikiran",2);
         m1.put("pranav",3);
         m1.put("Shashi",4);
         m1.put("S.rajesh",5);
         m1.put("T.rajesh",6);
         m1.put("vikas",7);
         System.out.println("sritesh");

        
    }

    
    }
