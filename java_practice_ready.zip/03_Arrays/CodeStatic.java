/**
 * CodeStatic
 */
package sritesh;
class Kurkure
{
    String brand;
    int cost;
    static String taste;
      
   static public void work(Kurkure obj)
    {
        System.out.println(obj.brand+":"+obj.cost+":"+obj.taste);
    }
}

 public class CodeStatic {

    //TO SET THE ISTANSE VARIABLE COMMON TO THE OBJECTS OF THAT CLASS
    //THEN THE STATIC KEYWORD IS USED TO SET THE VARIABLE COMMON TO ALL THE OBJECTS CREATED

    public static void main(String[] args) {
        
            Kurkure k1=new Kurkure();
            k1.brand="parleg";
            k1.cost=10;
            Kurkure.taste="crunchy";//HERE WE CAN USE THE CLASS NAME DIRECTLY FOR THE STATIC VARIBLE OBJECT


            Kurkure k2=new Kurkure();
            k2.brand="lays";
            k2.cost=15;
            Kurkure.taste="crunchy";

            Kurkure k3=new Kurkure();
            k3.brand="halkefulke";
            k3.cost=30;
            Kurkure.taste="crunchy";

            k1.taste="namkeen";//IF CHANGE MADE IN THE SATIC VARIABLE BY ANY OBJECT THE IT WILL BE COMMON TO ALL THE OTHER OBJECTS

            Kurkure.work(k1);

    }
}

//**STATIC METHODS */
  