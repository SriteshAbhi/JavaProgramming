class A 
{
    public void show()
    {
        System.out.println("in class A");
    }
}
class B extends A
{
    public void show()
    {
        System.out.println("in class b");
    }
}
class C extends B
{
    //public final int x=20;
    public void show()
    {
        System.out.println("in class c");
    }
}
public class DynamicDispatch {
    public static void main(String[] args) {
        ;
         
       A b1=new A();
        b1.show();
        b1 =new C();
        b1.show();
        b1=new A();

    }
    
}
