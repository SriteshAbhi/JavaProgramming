 @FunctionalInterface// the lamda expression works with only functional interface
 //the lamda expression is used inorder to reduce the no of lines of code
interface A
{
   

     int hello(int i);
     
}
    
class Fo implements A
{
    public int hello(int c)
    {
         return c+c;
    }

     
}
     
     
     
    
    public class TimePass {
        public static void main(String[] args)
         {
             A a1= (g) ->  g;
             A g1=new Fo();

                
             
           
            int r=g1.hello(5);
            System.out.println(r);
        
            
        }
    }
    

