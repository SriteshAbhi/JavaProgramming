/**
 * Inheritance
 */
public class job {

    
        public void add(int x,int y)
        {
            System.out.println(x+y);
        }
       
    }
class Inheritance
{
    public static void main(String[] args) {
        job j1=new job();
        j1.add(4,5);
    }
}