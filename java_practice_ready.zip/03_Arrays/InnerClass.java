static class K
{
    public  void hello()
    {
        System.out.println("hi there");
    }
     class  P{
        public void name()
        {
            System.out.println("my name is sritesh");
        }

    }
}


public class InnerClass {
    public static void main(String[] args) {

        
    
   K k1=new K();
   k1.hello();

   K.P kp= new K. P();
   kp.name();

    



    
}
}
