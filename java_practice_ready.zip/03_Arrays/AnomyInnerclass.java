class Go
{
    public void shoot()
    {
        System.out.println("in go class");
    }
}
public class AnomyInnerclass {

    public static void main(String[] args) {
        Go g1=new Go()
        {
            public void shoot()
            {
                System.out.println("in anomys calss");
            }
        };
        g1.shoot();
         
        
    }
}
