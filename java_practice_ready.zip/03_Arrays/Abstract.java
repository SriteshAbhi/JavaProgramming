// IF METHOD IS ABSTRACT -->CLASS IS ABSTRACT
//IF ANY CLASS INHERIT THE ABSTRACT CLASS THE IT SHOULD HAVE ALL THE ABSTRACT METHODS OF ABSTRACT CLASS
//WE CANT CREATE THE OBJECT OF THE ABSTRACT CLASS



abstract class Human
{
    public abstract void eating();
      
     abstract public void talkIng();
     abstract public void drinking();
}
 abstract  class Sritesh extends Human
{
  abstract  public void eating();
    {
        System.out.println("sritesh eating");
    }
    public void talkIng()
    {
        System.out.println("sritesh is talking");
    }
}
class Don extends Sritesh

{
   public void drinking()
   {
        System.out.println("ejuiiating");  
   }
   public void eating()
   {
    System.out.println("hello eating");
   }
   

}
     
public class Abstract {
    public static void main(String[] args) {
        Don s1=new  Don();
        s1.eating();
        s1.talkIng();
        s1.drinking();

    }
    
}
