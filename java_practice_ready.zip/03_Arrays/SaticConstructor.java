class Box
{
    String brand;
    int cost;
   static String name;
   
   static{
    name="flipkartBox";
    System.out.println("Static block called");
   }


    public Box( )
    {
         
         brand="";
         cost=10;
         System.out.println("constructor block called");

    }
}


public class SaticConstructor {
     
    
    
        public static void main(String[] args)
        throws ClassNotFoundException {
    
    
            Class.forName("Box");
       
         
       
        
    }
    }

    

