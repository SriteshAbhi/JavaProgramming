package telugu.Add;
class D
{
    public void print()
    {
        System.out.println("sritesh");
    }
}



public class Add {

    public static void main(String[] args) {
        D a1=new D();
        a1.print();
    }
     
       
    
}
 