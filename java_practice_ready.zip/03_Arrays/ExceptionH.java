public class ExceptionH {
    public static void main(String[] args) throws ArithmeticException {
        System.out.println("before the exception ");
        float  r = 0; // Declare r outside the try block
        int arr[]=new int[5];
        String name=null;
        try {
            r = (float) (9 / 8);
            System.out.println(name.charAt(0));
            System.out.println(arr[5]);
         } // This will cause an ArithmeticException
         catch(ArrayIndexOutOfBoundsException g)
         {
            System.out.println("limit la undu bro "+g);
         }
         catch ( ArithmeticException obj) {
            System.out.println("/0: " + obj);
        }
         catch ( Throwable obj) {
            System.out.println("null undhi kada : " + obj);
        }
         
        System.out.println("Value of r: " + r); // Now r can be accessed here
        System.out.println("execution completed");
    }
}
