interface Comp
{
    void code();
}
class Monitor implements Comp
{
    public void code()
    {
         System.out.println("coding..M.");
    }
}
class Laptop implements Comp
{
    public void code()
    {
        System.out.println("coding..C.");
    }
}
class Developer
{
    public void devApp( Comp obj)
    {
        obj.code();
    }

}

public class InterfaceUse {
    public static void main(String[] args) {
        Developer d1=new Developer();
        Laptop l1=new Laptop();
        Monitor m1=new Monitor();


        d1.devApp(m1);
    }
    
}
