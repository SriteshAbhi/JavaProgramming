public class boxingUn {
    public static void main(String[] args) {
        int val=10;
        Integer val2=val;
        System.out.println(val2); //auto-boxing

        int val1=val2; // auto -unboxing
        System.out.println(val1);
        String s1="1.5";
         int a=(int)  Float.parseFloat(s1);
        System.out.println(a*2);
    }
    
}
