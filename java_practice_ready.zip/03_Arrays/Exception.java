public class Exception {
    public static void main(String[] args) {
        int a=1;
        int b=0;
        

         
        int c=a/b;//critical statement //arithematic exception
        System.out.println("printing the c...."); 
        System.out.println(c);
        System.out.println("completed ");
    }

    public String getMessage() {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'getMessage'");
    }

    
}
