  /**
   * Inheritance
   */
class a
{
    public  void add(int x,int y)
    {
        System.out.println(x+y);
    }
}
class B extends a
{
    public void div(int c,int y)
    {
        float j=c/y;
        System.out.println(j);
    }
}
  
  
  
   public class Inheritance extends B
{
  public static void main(String[] args) {
    B a1=new B();
    a1.add(2,3);
    sub(8,9);
    a1.div(12,5);

    
  }
  public static void sub(int x,int y)
  {
    System.out.println(x-y);
  }
    
  }