// INTERFACES ARE FOR THREE TYPRS 
//1)NORAMal interface 2)functional interface or sam3)marker interface

interface A
{
   void kite();
   void fall();

}
interface M extends A
{
    void talk();

}
class B implements A,M
{ 

    
    public void kite() {
        System.out.println("kite flying");
         
    }

    
    public void fall() {
        System.out.println("falling");
 
    }


    
    public void talk() {
       System.out.println("talking");
    }

}
public class InterfaceUse2 {
    public static void main(String[] args) {
        
    
    
    M in=new B();
    in.talk();
    in.kite();
    in.fall();
}
}
