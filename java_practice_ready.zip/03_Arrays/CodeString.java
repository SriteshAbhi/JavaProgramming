public class CodeString {
     

//String class----------------------------->

    public static void main(String[] args) {
        String nam=new String("Ramagiriwar");
        nam=nam+" X";
       System.out.println(nam+" Sritesh");
        System.out.println(nam.equals("Ramagiriwar"));
        System.out.println(nam.concat("Sritesh"));

        String g1="hello";
        String g2="bro!";

        System.out.println(g1==g2); //STRINGS ARE UNMUTABLE WE CANT CHANGE THEM
 
        //WE CAN USE StringBuffer/StringBuilder ----="  "; for mutable the string
         
         StringBuffer name=new StringBuffer("hi ");
        name.append(g1);
        System.out.println(name);

        StringBuilder noida=new StringBuilder("hey ");
        noida.append(g2);
        System.out.println(noida);
    

    }
    
}
