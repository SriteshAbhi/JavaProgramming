package moon;
public class Hello {

    public static void main(String[] args) {
         Danger d1=new Danger();
        d1.show();
    }
}
 