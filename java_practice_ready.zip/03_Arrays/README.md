# 03_Arrays

This folder contains Java programs classified under **03_Arrays**.

## Files
- `Abstract.java`
- `Add.java`
- `Annotation.java`
- `AnomyInnerclass.java`
- `CodeStatic.java`
- `CodeString.java`
- `DownUpcasting.java`
- `DynamicDispatch.java`
- `Encapuslation.java`
- `Exception.java`
- `ExceptionH.java`
- `Final.java`
- `GetterSetter.java`
- `Hello.java`
- `Inheritance.java`
- `InnerClass.java`
- `InterfaceUse.java`
- `InterfaceUse2.java`
- `ObjectHashcode.java`
- `Practice.java`
- `SaticConstructor.java`
- `TimePass.java`
- `boxingUn.java`
- `job.java`

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
