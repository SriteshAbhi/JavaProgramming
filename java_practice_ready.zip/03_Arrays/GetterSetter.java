class Don
{
  private int accpin;
  private  int age;

  public void setAge(int age,Don d1)
  {
    Don d2=d1;
      d1.age=age;
  }
   public int getAge()
   {
    return age;

   }
   public void setaccpin(int accpin)
  {
       this.accpin=accpin;
  }
   public int getPin()
   {
    return accpin;

   }
}




public class GetterSetter {
    public static void main(String[] args) {
        Don d1=new Don();
        d1.setAge(12,d1);
        System.out.println(d1.getAge());
        // d1.setaccpin(12);
        // System.out.println(d1.getPin());
    }
    
}
