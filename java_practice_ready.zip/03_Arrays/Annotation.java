class Don{
    public void show()
    {
        System.out.println("in don");
    }
}
class Don1 extends Don{
    @Override// anotation that used to find out the logical error
    public void shows()//<- here is the logical eroor
    {
        System.out.println("in don1");
    }
}

public class Annotation {
    public static void main(String[] args) {
        Don1 d1=new Don1();
        d1.show();


    }
    
}
