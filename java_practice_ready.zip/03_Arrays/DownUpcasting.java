class A
{
    public void git1()
    {
        System.out.println("in a");
    }
}
class B extends A
{
    public void git2()
    {
        System.out.println("in B");
    }
}
 
    public class DownUpcasting {
    public static void main(String[] args) {
            A a1= new B();// here it is called as upcasting
                a1.git1();
                B b1= (B) a1;
                b1.git1();

            
                }
            
                 
    
}
