import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

public class InputByUser {
    public static void main(String[] args) throws IOException {
         System.out.print("enter :");
    //      InputStreamReader ko=new InputStreamReader( System.in);
    //      BufferedReader br=new BufferedReader(ko);
    //      int g=Integer.parseInt( br.readLine());
    //      System.out.println(g);
    //    br.close();
    Scanner sc=new Scanner(System.in);
    int m=(int)sc.nextFloat();
    System.out.println(m);
    }
    
}
