import java.io.*;
import java.util.*;

public class Solution {

    public static void main(String[] args) 
    {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner sc = new Scanner(System.in);
        int num = sc.nextInt();
        int sum = 0;
        int sum1= 0;
        for(int i=1;i<=num;i++)
        {
            sum = sum + i;
        }
        for(int i=1;i<=num-1;i++)
        {
            sum1 = sum1 + sc.nextInt();
        }
        int result = sum - sum1;
        System.out.println(result);
        
    }
}