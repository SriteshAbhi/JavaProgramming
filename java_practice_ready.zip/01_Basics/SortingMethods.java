import java.util.Scanner;

class Bubble
{
    public static void BubbleSort(int[] arr)
    {
        for(int i=0;i<arr.length-1;i++)
        {
            for(int j=0;j<arr.length-i-1;j++)
            {
                if(arr[j]>arr[j+1])
                {
                    int temp=arr[j];
                    arr[j]=arr[j+1];
                    arr[j+1]=temp;
                }

            }
        }
        System.out.print("{");
    for(int n:arr)
    {
        System.out.print(n+",");
    }
    System.out.print("}");
    }

}
class Selection
{
  public static void SelectionSort(int[] arr)
  {
    for(int i=0;i<arr.length;i++)
    { 
                 int smallest=i;
                  for(int j=i+1;j<arr.length;j++)
                  {
                      if(arr[smallest]>arr[j])
                          {
                            smallest=j;
                          }
        
                  }
    int temp=arr[i];
    arr[i]=arr[smallest];
    arr[smallest]=temp;
    }
    System.out.print("{");
    for(int n:arr)
    {
        System.out.print(n+",");
    }
    System.out.print("}");
 }


}

class Insertion
{
    public static void InsertionSort(int[] arr)
    {
        for(int i=1;i<arr.length;i++)
        {
            int current = arr[i];
            int sorted=i-1;
            while(sorted>=0 && current<arr[sorted])
            {
                arr[sorted+1]=arr[sorted];
                sorted--;    
            }
            arr[sorted+1]=current;
        }
        System.out.print("{");
        for(int n:arr)
        {
            System.out.print(n+",");
        }
        System.out.print("}");
        }
        
}


public class SortingMethods {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter the size of array:");
        int size=sc.nextInt();
        int[] sri=new int[size];
        System.out.print("Enter the all elements sep by space:");
        for(int i=0;i<size;i++)
             sri[i]=sc.nextInt();
         System.out.print("SORTING_METHODS_\n");
         while(1>0)
         {
         System.out.print("1.BubbleSort\n2.selectionSort\n3.InsertionSort\nEnter your option:");
         int option=sc.nextInt();
         switch(option)
         {
            case 1->Bubble.BubbleSort(sri);
            case 2->Selection.SelectionSort(sri);
            case 3->Insertion.InsertionSort(sri);
            default->System.out.println("{please select the give methods}");
         }
         System.out.println();
         System.out.println();
        }
         
        

        
    }
    
}
