                  //object//
                    
                  //Throwable//

 //errors//                         //exceptions//
                                    
                                  
 //threaddeath,ioError              //runtime//    //sqlException//    //ioException//

 //outOfMemory//                     //Aritehematic,array.nullpointr