# 01_Basics

This folder contains Java programs classified under **01_Basics**.

## Files
- `ArrayList.java`
- `Finally.java`
- `InputByUser.java`
- `Solution.java`
- `SortingMethods.java`
- `sub.java`
- `tempCodeRunnerFile.java`
- `topclass.java`

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
