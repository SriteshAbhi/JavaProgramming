import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Finally {
    public static void main(String[] args) throws IOException {
        int i=0;
        
        try(BufferedReader bf=new BufferedReader(new InputStreamReader(System.in));)
        {
            System.out.print("enter:");
              
             i=Integer.parseInt(bf.readLine());
             System.out.println(i);
        }
        
    }
    
}
