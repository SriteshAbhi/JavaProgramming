
package moon;
public class Danger {
    public  void show()
    {
        System.out.println("hello");
    }
}
