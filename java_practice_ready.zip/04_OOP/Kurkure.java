
public class Kurkure {

}
