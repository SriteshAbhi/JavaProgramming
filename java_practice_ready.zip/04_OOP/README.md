# 04_OOP

This folder contains Java programs classified under **04_OOP**.

## Files
- `Annoation.java`
- `Danger.java`
- `Green.java`
- `Kurkure.java`
- `MyProblemException.java`
- `comparable.java`
- `integer.java`
- `string.java`

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
