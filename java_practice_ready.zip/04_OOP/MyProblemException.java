
public class MyProblemException {

}
