
public class integer {

}
