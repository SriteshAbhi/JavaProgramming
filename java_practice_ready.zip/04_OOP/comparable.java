
public interface comparable<T> {

}
