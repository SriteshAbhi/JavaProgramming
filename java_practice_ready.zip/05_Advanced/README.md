# 05_Advanced

This folder contains Java programs classified under **05_Advanced**.

## Files
- (no files)

## How to run
1. `javac <FileName>.java`
2. `java <MainClassName>`
